import React from 'react'
import Image from 'next/image'
import { Logos } from '../../../assets'
import styles from './News.module.css'
import { base_url, getMenuByName } from '../../../endpoints'
import Link from 'next/link'
import FetchAPI from '../../../API'

const NewsCard = (props) => {
  const { title, description, image, category_news } = props
  let strippedString = title?.replace(/(<([^>]+)>)/gi, '')
  //   console.log('title', strippedString)

  const myLoader = ({ src, width, quality }) => {
    return `${base_url}/${src}?w=${width}&q=${quality || 75}`
  }

  const getDataMenu = async (x) => {
    FetchAPI(getMenuByName(x)).then((data) => {
      if (data.success) {
        // console.log('data?.data[0]?.parent_target_id=>', data)
        localStorage.setItem(
          'categorieTitle',
          JSON.stringify({
            tidChild: data?.data[0]?.tid,
            parent: data?.data[0]?.parent_target_id_1,
            child: data?.data[0]?.name_1,
            contenuArticle:
              data?.data[0]?.field_contenu_default !== ''
                ? data?.data[0]?.field_contenu_default
                : data?.data[0]?.name_1,
          })
        )
        localStorage.setItem(
          'tid',
          JSON.stringify(data?.data[0]?.parent_target_id)
        )
      }
    })
  }

  return (
    <div className={`${styles.CardNews} card m-2`}>
      <Link
        role='button'
        href={{
          pathname: '/article/' + strippedString?.split(' ').join('-'),
          search: '',
          hash: '',
          query: {
            fromNav: {},
            title: strippedString,
            selectedItem: strippedString,
            from: 'News',
            contenuArticle: '',
          },
        }}
        as={'/article/' + strippedString?.split(' ')?.join('-')}
      >
        <a
          onClick={() => getDataMenu(strippedString)}
          className='text-decoration-none text-black'
        >
          <div class={styles.ribbon}>
            <span>{category_news}</span>
          </div>
          {image?.trim() ? (
            <Image
              className='card-img-top p-2 pt-3'
              objectFit='cover'
              width={16}
              height={9}
              layout='responsive'
              quality={65}
              loader={myLoader}
              src={image}
              alt={strippedString}
            />
          ) : (
            <Image
              className={`card-img-top  p-2 pt-3`}
              src={Logos.logo_hadith_m6}
              objectFit='cover'
              width={16}
              height={9}
              layout='responsive'
              quality={65}
              alt='logo-Al-hadith-Mohammed-VI'
              title='logo Al hadith Mohammed VI'
            />
          )}

          <div className={`${styles.cardBody} card-body`}>
            <h3 className='card-title text-end fs-5'>{strippedString}</h3>
            <p className='card-text'>{description}</p>
            <div className='d-flex justify-content-center'>
              <button className='btn btn-md mt-3' type='submit'>
                <i
                  className='fas fa-long-arrow-alt-left'
                  style={{
                    marginRight: '1em',
                  }}
                />
                {'لمعرفة المزيد'}
              </button>
            </div>
          </div>
        </a>
      </Link>
    </div>
  )
}

export default NewsCard
