import { useRouter } from 'next/router'
import React, {useContext, useEffect, useState} from 'react'
import Body from '../../../components/Body'
import ItemList from '../../../components/ItemList'
import TemplateArticle from '../../../components/TemplateArticle'
import { AppContext } from '../../../Context/AppContextApi'
import _ from 'lodash'
import { FetchPostAPI } from '../../../data/API_Search/API'
import { Search } from '../../../endpoints'
import CustomModal from '../../../components/_UI/Modal'
import Loading from '../../../components/_UI/Loading'

function Hadith(props) {
    const {hadith} = useContext(AppContext)
    const urlSearch = Search()
    const [dataHadith, setDataHadith] = useState({})
    const [numberHadith, setNumberHadith] = useState('')
    const [showDialog, setshowDialog] = useState(false)
    const [showDialogModal, setshowDialogModal] = useState(false)
    const [message, setMessage] = useState('')
    const router = useRouter()?.query
    
    useEffect(() =>{
      const split_string = router?.hadith?.split(/(\d+)/)
      setNumberHadith(split_string && split_string[1])
    },[router])

    // console.log('numberHadith', numberHadith)

    const data = [
        {
          title: 'الرئيسية',
          path: '',
        },
        {
          title: 'البحث',
          path: 'search',
        },
      ]

    const handleSearch = async () => {
      // console.log('numberHadith', numberHadith)
      const data = {
        content: '',
        evaluationSource: '',
        idDegree: '',
        codeDegree: '',
        idNarrator: '',
        idSource: '',
        idTopic: '',
        idCategorie: '',
        numeroHadith: numberHadith,
        size: 10,
        start:  0 ,
        tags: '',
      }
  
      FetchPostAPI(urlSearch, data).then((data) => {
        if (data.success) {
          // console.log('data?.data',data?.data)
          setDataHadith(data?.data?.hits?.hits[0])
        }
      })
    }
    useEffect(()=>{
      if(numberHadith){
        handleSearch()
      }
    },[numberHadith])

    if (_.isEmpty(dataHadith)) {
      return (
        <div className='d-flex align-items-center justify-content-center py-5'>
          <Loading />
        </div>
      )
    }
  return (
    <TemplateArticle {...props} ListBreadcrumb={data} titlePage='البحث'
      pageMeta= {{
        title: `${dataHadith?._source?.content?.split("").slice(0, 60).join("")}...`,
        description:`${dataHadith?._source?.content?.split("").slice(0, 155).join("")}...`,
        keywords:`${dataHadith?._source?.narrator?.label},${dataHadith?._source?.source?.label},${dataHadith?._source?.categorie?.label},${dataHadith?._source?.degree.label} `,
      }}
    >
        <Body
        className={` TemplateArticleBody SearchPage  p-4`}
        >
            <noscript
            dangerouslySetInnerHTML={{
                __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NGQL2RC"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
            }}
            ></noscript>
            <ItemList 
                topic={dataHadith?._source?.topic?.label}
                category={dataHadith?._source?.categorie?.label}
                content={dataHadith?._source?.content}
                highlight={!!dataHadith.highlight}
                onSubmitWTSP={() => {
                  if (dataHadith?._source?.content.length > 5110) {
                    //handleShow();
                    setMessage('هذا الحديث طويل, لن يتم مشاركته بالكامل')
                    setshowDialog(false)
                    setshowDialogModal(true)
                  } else {
                    setshowDialog(true)
                    setshowDialogModal(false)
                  }
                }}
                onSubmit={() => {
                  if (dataHadith?._source?.content.length > 750) {
                    //handleShow();
                    setMessage('هذا الحديث طويل, لن يتم مشاركته بالكامل')
                    setshowDialog(false)
                    setshowDialogModal(true)
                  } else {
                    setshowDialog(true)
                    setshowDialogModal(false)
                  }
                }}
                showDialog={true}
                text={
                  dataHadith?.highlight ? dataHadith?.highlight?.content[0] : dataHadith?._source?.content
                }
                narrator={dataHadith?._source?.narrator?.label}
                source={dataHadith?._source?.source?.label}
                degree={dataHadith?._source?.degree}
                sourceGlobal={dataHadith?._source?.evaluationSource}
                comments={dataHadith?._source?.comments}
                tags={dataHadith?._source?.tags}
                numeroHadith={dataHadith?._source?.numeroHadith}
                showLink={false}
            />
            {showDialogModal && (
              <CustomModal
                title={'تنبيه'}
                body={message}
                show={showDialogModal}
                onHide={() => {
                  setshowDialog(false)
                  setshowDialogModal(false)
                }}
                onClick={() => {
                  setshowDialog(true)
                  setshowDialogModal(false)
                }}
              />
            )}
        </Body>
    </TemplateArticle>
  )
}

export default Hadith