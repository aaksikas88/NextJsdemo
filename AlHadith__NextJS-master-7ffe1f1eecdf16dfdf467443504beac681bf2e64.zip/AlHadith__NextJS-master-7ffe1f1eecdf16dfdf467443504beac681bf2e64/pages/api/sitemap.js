import { SitemapStream, streamToPromise } from 'sitemap'
import { getMenu, getSideArticle } from '../../endpoints'
import { handleMenu } from '../../helpers'
import axios from 'axios'
import { includes } from 'lodash'

export default async (req, res) => {
  // console.log('*******req.headers.host******=>', req.headers.host)
  if (
    req.headers.host === 'hadithm6.ma' ||
    req.headers.host === 'hadithm6.com'
  ) {
    // console.log('*******req.headers.host ok ******=>')
    try {
      const smStream = new SitemapStream({
        hostname: `http://${req.headers.host}`,
        cacheTime: 600000,
      })

      // List of posts

      const url = getMenu()
      const getData = await axios.get(url)
      const gropData = handleMenu(getData.data)
      // const mapD = gropData.map((item) =>
      //   item?.label === 'البرامج الإعلامية' || item?.label === 'التلفزة الرقمية'
      //     ? null
      //     : console.log('item.items', item.items)
      // )

      const mapData = gropData.map((item) =>
        item?.label === 'البرامج الإعلامية' || item?.label === 'التلفزة الرقمية'
          ? null
          : item.items
      )
      const articles = [].concat.apply([], mapData)

      const promessArticles = await Promise.all(
        articles?.map(async (el) => {
          const urlSideArticles = getSideArticle(
            el?.title,
            el?.tID,
            el?.parentLabel
          )
          return await axios.get(encodeURI(urlSideArticles)).then((res) => {
            return res?.data
          })
        })
      ).then((data) => {
        var ttt = [].concat.apply([], data)
        return ttt
      })
      // console.log('ttttt', promessArticles)

      const test = [
        { title: 'الدروس-الحديثية', subDomain: 'media' },
        { title: 'الدروس-الحسنية', subDomain: 'media' },
        { title: 'برامج-تلفزية', subDomain: 'media' },
        { title: 'برامج-اذاعية', subDomain: 'media' },
        { title: 'برامج-على-الشبكات-الاجتماعية', subDomain: 'media' },
        { title: 'الدروس-التمهيدية', subDomain: 'media' },
        { title: 'الدروس-البيانية', subDomain: 'media' },
        { title: 'AllMedia', subDomain: '' },
        { title: '', subDomain: '' },
      ]

      const t = [...test, ...articles, ...promessArticles]
      // console.log('req.headers.host =====', t)

      // Create each URL row
      /* Looping through the articles array and creating a new variable called test. */
      if (articles.length > 0) {
        t?.map((article) =>
          smStream.write({
            url: article?.subDomain
              ? `/${article.subDomain}/${article?.title}`
              : article?.title?.includes('<a')
              ? `/article/${
                  article?.title
                    ?.replace(/(<([^>]+)>)/gi, '')
                    ?.split(' ')
                    .join('-') || ''
                }`
              : `/article/${article?.title?.split(' ').join('-') || ''}`,
            changefreq: 'daily',
            priority: 0.9,
          })
        )
      }

      // End sitemap stream
      smStream.end()

      // XML sitemap string
      const sitemapOutput = (await streamToPromise(smStream)).toString()

      // Change headers
      res.writeHead(200, {
        'Content-Type': 'application/xml',
      })

      // Display output to user
      res.end(sitemapOutput)
    } catch (e) {
      console.log(e)
      res.send(JSON.stringify(e))
    }
  }
}
