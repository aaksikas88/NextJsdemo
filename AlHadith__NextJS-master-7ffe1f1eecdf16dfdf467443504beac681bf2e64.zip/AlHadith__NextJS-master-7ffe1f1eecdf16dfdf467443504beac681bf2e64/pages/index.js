import React from 'react'
import useTranslation from 'next-translate/useTranslation'
import HomeScreen from './home'
import { getMenuList } from '../lib/menu'
import { getAllCommanderie } from '../lib/commanderieCroyants'
import { getDataAhadith } from '../lib/ahadith'
import Head from 'next/head'

export default function Home(props) {
  const { t } = useTranslation()
  const description = t('description')
  const linkName = t('more-examples')

    // console.log('hooooooommme', props)
    return (
        <>
            <Head>
                <script
                dangerouslySetInnerHTML={{
                    __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                    })(window,document,'script','dataLayer','GTM-NGQL2RC');`,
                }}
                ></script>
                <meta charSet='utf-8' />
                <meta name='viewport' content='width=device-width' />
                {/* <meta name='viewport' content='width=device-width, initial-scale=1' /> */}
                <meta name='theme-color' content='#129D59' />
                <meta name='description' content='منصة محمد السادس للحديث الشريف' />
                <meta
                name='keywords'
                content='٫ اوقات الصلاة٫ وزارة الأوقاف والشؤون الإسلامية٫ اسلام٫ المغرب'
                />
                <link
                rel='apple-touch-icon'
                sizes='180x180'
                href='/apple-touch-icon.png'
                />
                <link
                rel='icon'
                type='image/png'
                sizes='32x32'
                href='/favicon-32x32.png'
                />
                <link
                rel='icon'
                type='image/png'
                sizes='16x16'
                href='/favicon-16x16.png'
                />
                <link rel='manifest' href='/site.webmanifest' />
                <meta name='msapplication-TileColor' content='#da532c' />
                <meta name='theme-color' content='#ffffff' />
                <link rel='preconnect' href='https://backend.hadithm6.com' />
                <link rel='preconnect' href='https://apisearch.hadithm6.com' />
                <link rel='preconnect' href='https://fonts.googleapis.com' />
                <link rel='preconnect' href='https://fonts.gstatic.com' crossOrigin />
                <link
                href='https://fonts.googleapis.com/css2?family=Almarai:wght@300&display=swap'
                rel='stylesheet'
                />
                <title>منصة محمد السادس للحديث الشريف</title>
            </Head>
            <HomeScreen {...props} />
        </>
    )
}
export const getServerSideProps = async ({ query, params }) => {
    const MenuGlobal = await getMenuList()
    const dataAPI = await getAllCommanderie()
    const dataALhadith = await getDataAhadith()
  
    return {
      props: JSON?.parse(
        JSON?.stringify({
          MenuGlobal: MenuGlobal,
          dataAPI: dataAPI,
          dataAhadith: dataALhadith,
        })
      ),
    }
  }
  
// export async function getStaticProps(ctx) {
//     const props = await loadNamespaces({
//         ...ctx,
//         pathname: '/',
//     })

//     return {props:JSON.parse(JSON.stringify(props))}
// }
