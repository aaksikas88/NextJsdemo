import dynamic from 'next/dynamic'
import React, { useEffect, useState } from 'react'
import FetchAPI from '../API'
import { getNewSections } from '../endpoints'
import Body from '../components/Body'
import Layout from '../components/Layout'
import Loading from '../components/_UI/Loading'
const TopBar = dynamic(() => import('../components/Navs/TopBar'), {
  loading: () => <Loading />,
})
const NavBar = dynamic(() => import('../components/Navs/Navbar'),{
  loading: () => <Loading />,
})
const Footer = dynamic(() => import('../components/Footer'),{
  loading: () => <Loading />,
})
const CarouselHome = dynamic(() => import('./homePage/CarouselHome'), {
  loading: () => <Loading />,
})
// import CommanderieCroyants from './homePage/CommanderieCroyants'
const CommanderieCroyants = dynamic(() =>
  import('./homePage/CommanderieCroyants'),{loading: () => <Loading />,}
)
const Resources = dynamic(() => import('./homePage/Resources'), {
  loading: () => <Loading />,
})
const Alahadiths = dynamic(() => import('./homePage/Alahadiths'), {
  loading: () => <Loading />,
})
const SearchSection = dynamic(() => import('./homePage/searchHome'), {
  loading: () => <Loading />,
})
const DownloadApk = dynamic(() => import('../components/downloadApk'), {
  loading: () => <Loading />,
})
const Videos = dynamic(() => import('./homePage/Videos'), {
  loading: () => <Loading />,
})
const Theme1 = dynamic(() => import('../components/Theme1'), {
  loading: () => <Loading />,
})
const Theme2 = dynamic(() => import('../components/Theme2'), {
  loading: () => <Loading />,
})
const ScrollButton = dynamic(() => import('../components/ScrollButton'), {
  loading: () => <Loading />,
})
const DoroussHaditha = dynamic(() => import('./homePage/DoroussHaditha'),{
  loading: () => <Loading />,
})
const News = dynamic(() => import('./homePage/News'),{
  loading: () => <Loading />,
})

const HomeScreen = (props) => {
  const [sections, setSections] = useState([])
  const [dataSection, setdataSection] = useState([])
  const url = getNewSections()
  const getData = async () => {
    FetchAPI(url).then((data) => {
      if (data.success) {
        setSections(data?.data)
      }
    })
  }

  const renderSwitch = (theme, data) => {
    switch (theme) {
      case 'theme1':
        return (
          <div style={{ marginTop: 60 }}>
            <Theme1 title={data} />
          </div>
        )
      case 'theme2':
        return (
          <div style={{ marginTop: 60 }}>
            <Theme2 title={data} />
          </div>
        )
      default:
        return <></>
    }
  }

  useEffect(() => {
    getData()
  }, [])
  return (
    <Layout>
      <TopBar />
      <NavBar {...props} />
      <Body>
        <noscript
          dangerouslySetInnerHTML={{
            __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NGQL2RC"
height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
          }}
        ></noscript>
        <ScrollButton />
        <CarouselHome />
        <h1 className='d-none'>'منصة محمد السادس للحديث الشريف'</h1>
        <SearchSection />
        <News />
        <CommanderieCroyants {...props} />
        <DoroussHaditha />
        <Resources />
        <Alahadiths {...props} />
        <Videos />
        {sections &&
          sections.length > 0 &&
          sections.map((item, index) => {
            // getdataSection(item.term_node_tid)
            return renderSwitch(item.field_theme_accueil, item.term_node_tid)
          })}
        <DownloadApk />
      </Body>
      <Footer />
    </Layout>
  )
}
export default HomeScreen
