import React, { useEffect } from 'react'
import appWithI18n from 'next-translate/appWithI18n'
// import i18nConfig from '../i18n'
import Head from 'next/head'
import Script from 'next/script'
import '../public/css/bootstrap.min.css'
import '../public/css/fonts.css'
import '../public/css/all.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-icons/font/bootstrap-icons.css'
import '../styles/custom.css'
import '../styles/Keyboard.scss'
import '../styles/Tabs.css'
import '../styles/WebTV.css'
import '../styles/CarouselHome.css'
import '../styles/SocialMedia.css'
import '../styles/SearchResult.css'
import '../styles/AllMedia.css'
import '../styles/Modal.css'
import '../styles/QandA.css'
import '../styles/medias.css'
import '../styles/styleFix.css'
import '../styles/DownloadAPK.css'
import '../styles/articleByTags.css'
import '../styles/sliderList.css'
import '../styles/itemList.css'
import { AppProvider } from '../Context/AppContextApi'

import { SSRProvider } from '@react-aria/ssr'

function MyApp({ Component, pageProps }) {
  useEffect(() => {
    import('../public/js/bootstrap.bundle.min')
  })

  return (
    <>
      <SSRProvider>
        <AppProvider>
          <Component {...pageProps} />
        </AppProvider>
      </SSRProvider>
    </>
  )
}

export default MyApp
