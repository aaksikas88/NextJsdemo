import React, { useEffect, useState } from 'react'
import {
  getQuestionbyID,
  AllForums,
  searchQuestion,
  base_url,
} from '../../endpoints'
import FetchAPI from '../../API'
import Link from 'next/link'
import { useRouter } from 'next/router'
import _ from 'lodash'
import Loading from '../../components/_UI/Loading'
import TemplateArticle from '../../components/TemplateArticle'
import Body from '../../components/Body'
import styles from './detailsQuestion.module.css'
import { FetchPostAPI } from '../../data/API/questions'

const Questions = () => {
  const { state } = useRouter()?.query
  let route = useRouter()
  const [Qts, setQts] = useState({})
  useEffect(()=>{
    setQts(typeof window !== 'undefined' &&
    JSON.parse(localStorage.getItem('Question')))
  },[route])

  const itemQuestion = useRouter()?.query?.itemQuestion ? useRouter()?.query?.itemQuestion : Qts?.itemQuestion
  const itemReponse = useRouter()?.query?.itemReponse?.replace(/span/g, 'a') ? useRouter()?.query?.itemReponse?.replace(/span/g, 'a') : Qts?.itemReponse?.replace(/span/g, 'a')
  const itemTitle = useRouter()?.query?.itemTitle ? useRouter()?.query?.itemTitle : Qts?.itemTitle
  const item_id = useRouter()?.query?.itemId ? useRouter()?.query?.itemId : Qts?.itemId

  
  const [dataQuestion, setDataQuestion] = useState([])
  const [questionInfos, setQuestionInfos] = useState(null)
  const urlSearchQuestion = searchQuestion()

  const itemAnswer = questionInfos?.descriptionReponse?.replace(/span/g, 'a')

  const handleSearchQuestion = async () => {
    const data = {
      query: itemTitle || questionInfos?.sujetQuestion,
      size: 10,
      start: 0,
    }
    FetchPostAPI(urlSearchQuestion, data).then((data) => {
      if (itemTitle !== '' && data.success) {
        return setDataQuestion(data?.data)
      } else {
        setDataQuestion([])
      }
    })
  }

  useEffect(() => {
    handleSearchQuestion()
  }, [itemQuestion, questionInfos?.sujetQuestion])

  const data = [
    {
      title: 'الرئيسية',
      path: '',
    },
    {
      title: 'سؤال و جواب',
      path: 'QuestionsReponses',
    },
  ]

  // if (_.isEmpty(dataQuestion.data)) {
  //   return (
  //     <div className='d-flex align-items-center justify-content-center py-5'>
  //       <Loading />
  //     </div>
  //   )
  // }
  // console.log(itemReponse)
  useEffect(() => {
    if (document) {
      const t = document.getElementsByClassName('numeroHadith')
      for (var i = 0; i < t.length; i++) {
        t[i].href = `/search?idHadith=${t[i].textContent}&from=question`
        // t[i].target = `_blanck`
      }

      // console.log(t.childNodes)
    }
  }, [itemReponse, itemAnswer])
  
  return (
    <TemplateArticle ListBreadcrumb={data} titlePage='سؤال و جواب'
      pageMeta= {{
        title: questionInfos?.sujetQuestion?.split("")?.slice(0, 60)?.join("") || itemTitle?.split("")?.slice(0, 60)?.join(""),
        description:questionInfos?.descriptionQuestion ? `${questionInfos?.descriptionQuestion?.split("").slice(0, 155).join("")}...` : `${itemQuestion?.split("").slice(0, 155).join("")}...`,
        keywords:'٫ البحث في منصة الحديث النبوي الشريف, سؤال , جواب, الحديث النبوي',
      }}
    >
      <Body
        className={`${styles.TemplateArticleBody} ${styles.QuAnswer} Media d-flex p-4`}
      >
        <noscript
          dangerouslySetInnerHTML={{
            __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NGQL2RC"
height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
          }}
        ></noscript>
        <div className={`${styles.quesList} px-4 flex-fill`}>
          {questionInfos ? (
            questionInfos?.descriptionReponse ? (
              <div>
                <h3>السؤال</h3>
                <div className={`${styles.card} card w-100 mb-5 mt-3`}>
                  <div
                    className={`${styles.CardQuestion} card-body Card-question`}
                  >
                    <h5 className='col-9 d-flex card-subtitle'>
                      {questionInfos?.sujetQuestion}
                    </h5>
                    <p className='p mt-3 card-text'>
                      {questionInfos?.descriptionQuestion}
                    </p>
                  </div>
                </div>
                <h3>الإجابة</h3>
                <div
                  className={` ${styles.cardAnswer} card Card-answer1 w-100 mb-5 mt-3`}
                  style={styles.CardAnswer1}
                >
                  <div className='card-body bg-success'>
                    <div
                      className='p card-text text-justify '
                      dangerouslySetInnerHTML={{
                        __html: itemAnswer,
                      }}
                    >
                      {/* {questionInfos?.descriptionReponse} */}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <h3 className={'h3'}>السؤال</h3>
                <div className='card w-100 mb-5 mt-3'>
                  <div
                    className={`${styles.CardQuestion} card-body Card-question `}
                  >
                    <h5 className='col-9 d-flex card-subtitle'>
                      {questionInfos?.sujetQuestion}
                    </h5>
                    <p className='p mt-3 card-text'>
                      {questionInfos?.descriptionQuestion}
                    </p>
                  </div>
                </div>
                <div
                  className={`${styles.cardAnswer} card Card-answer1 w-100 my-5`}
                >
                  <div className='card-body '>
                    <p className='p card-text'>{'لا توجد إجابات حتى الآن'}</p>
                  </div>
                </div>
              </div>
            )
          ) : itemReponse ? (
            <div>
              
              <h3>السؤال</h3>
              <div className={`${styles.card} card w-100 mb-5 mt-3`}>
                <div
                  className={`${styles.CardQuestion} card-body Card-question`}
                >
                  <h5 className='col-9 d-flex card-subtitle'>{itemTitle}</h5>
                  <p className='p mt-3 card-text'>{itemQuestion}</p>
                </div>
              </div>
              <h3>الإجابة</h3>
              <div
                className={` ${styles.cardAnswer} card Card-answer1 w-100 mb-5 mt-3`}
                style={styles.CardAnswer1}
              >
                <div className='card-body '>
                  <p
                    id='test'
                    className='p card-text text-justify'
                    dangerouslySetInnerHTML={{
                      __html: itemReponse,
                    }}
                  >
                    {/* {itemReponse} */}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <h3 className={'h3'}>السؤال</h3>
              <div className='card w-100 mb-5 mt-3'>
                <div
                  className={`${styles.CardQuestion} card-body Card-question `}
                >
                  <h5 className='col-9 d-flex card-subtitle'>{itemTitle}</h5>
                  <p className='p mt-3 card-text'>{itemQuestion}</p>
                </div>
              </div>
              <div
                className={`${styles.cardAnswer} card Card-answer1 w-100 my-5`}
              >
                <div className='card-body '>
                  <p className='p card-text'>{'لا توجد إجابات حتى الآن'}</p>
                </div>
              </div>
            </div>
          )}
          {/* {itemReponse ? (
            <div>
              <h3>السؤال</h3>
              <div className={`${styles.card} card w-100 mb-5 mt-3`}>
                <div
                  className={`${styles.CardQuestion} card-body Card-question`}
                >
                  <h5 className='col-9 d-flex card-subtitle'>{itemTitle}</h5>
                  <p className='p mt-3 card-text'>{itemQuestion}</p>
                </div>
              </div>
              <h3>الإجابة</h3>
              <div
                className={` ${styles.cardAnswer} card Card-answer1 w-100 mb-5 mt-3`}
                style={styles.CardAnswer1}
              >
                <div className='card-body '>
                  <p className='p card-text text-justify '>{itemReponse}</p>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <h3 className={'h3'}>السؤال</h3>
              <div className='card w-100 mb-5 mt-3'>
                <div
                  className={`${styles.CardQuestion} card-body Card-question `}
                >
                  <h5 className='col-9 d-flex card-subtitle'>{itemTitle}</h5>
                  <p className='p mt-3 card-text'>{itemQuestion}</p>
                </div>
              </div>
              <div
                className={`${styles.cardAnswer} card Card-answer1 w-100 my-5`}
              >
                <div className='card-body '>
                  <p className='p card-text'>{'لا توجد إجابات حتى الآن'}</p>
                </div>
              </div>
            </div>
          )} */}
        </div>
        <div className={`${styles.sidBar} side-bar px-4`}>
          <p className={`${styles.p} ${styles.tiitle}`}>مواد ذات صلة</p>
          <div className={styles.SimpleList}>
            {dataQuestion?.hits?.hits?.map((item, i) => {
              //console.log('id_item____', item?._id)
              return item_id !== item?._id ? (
                <Link
                  key={i}
                  exact
                  className='item d-flex align-items-center py-3 px-1'
                  passHref={true}
                  href={{
                    pathname: '/detailsQuestion',
                    query: {
                      itemTitle: item?._source?.sujetQuestion,
                      itemQuestion: item?._source?.descriptionQuestion,
                      itemReponse: item?._source?.descriptionReponse,
                    },
                  }}
                  as={'/detailsQuestion'}
                  onClick={() => {
                    // if (typeof window != 'undefined') {
                    //   window.location.reload()
                    // }
                    setQuestionInfos(item?._source)
                  }}
                >
                  <a
                    className={`${styles.item} d-flex align-items-center py-3 px-1 text-decoration-none`}
                  >
                    {item?._source?.sujetQuestion}
                  </a>
                </Link>
              ) : null
            })}
          </div>
        </div>
      </Body>
    </TemplateArticle>
  )
}

export default Questions
