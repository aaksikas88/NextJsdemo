const Article = {
  thumbnail_article_1: require('./thumbnail_article_1.png'),
  photo_sliderlist: require('./photo_sliderlist.png'),
};

export default Article