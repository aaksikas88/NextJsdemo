const Backgrounds = {
    bg_arabic_design: require('./bg-arabic-design.svg'),
    bg_arabic_design_slide: require('./bg-arabic-design-slide.svg'),
    bg_dashed: require('./bg_dashed.svg'),
    bg_le_roi_mohamed_vi: require('./bg_le_roi_mohamed_vi.png'),
    bg_casa: require('./bg_casa.png'),
};

export default Backgrounds