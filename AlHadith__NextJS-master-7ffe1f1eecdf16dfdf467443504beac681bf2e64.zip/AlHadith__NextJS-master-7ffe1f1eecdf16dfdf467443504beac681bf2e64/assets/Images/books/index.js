const books = {
    book1: require('./book1.png'),
    book2: require('./book2.png'),
    book3: require('./book3.png'),
  };
  
  export default books