const our_partners = {
  logo_1: require('./logo-1.png'),
  logo_2: require('./logo-2.png'),
  logo_3: require('./logo-3.png'),
  logo_4: require('./logo-4.png'),
};

export default our_partners