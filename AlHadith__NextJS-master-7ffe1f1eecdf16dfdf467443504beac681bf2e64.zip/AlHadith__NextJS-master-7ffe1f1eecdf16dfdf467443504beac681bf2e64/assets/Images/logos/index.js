import our_partners from './OurPartners'

const Logos = {
  logo_web: require('./logo-alhadith-mohamed-6-center.svg'),
  logo_new: require('./logo_M6_hadith.svg'),
  logo_portail_hadith: require('./logo_portail_hadith_m6.svg'),
  logo_hadith_m6: require('./logo_hadith_m6.svg'),
  our_partners,
}

export default Logos
