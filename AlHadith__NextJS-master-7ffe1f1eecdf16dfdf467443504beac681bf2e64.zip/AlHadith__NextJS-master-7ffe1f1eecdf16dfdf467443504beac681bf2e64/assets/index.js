export { default as Logos } from './Images/logos';
export { default as Icons } from './Images/icons';
export { default as Backgrounds } from './Images/backgrounds';
export { default as Books } from './Images/books';
export { default as Article } from './Images/article';
export { default as Logo } from './Images/logos/logo_M6_hadith.svg';
