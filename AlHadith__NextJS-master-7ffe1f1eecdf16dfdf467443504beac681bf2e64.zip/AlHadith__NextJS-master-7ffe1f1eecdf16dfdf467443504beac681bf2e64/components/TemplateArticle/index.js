import NavBar from '../Navs/Navbar'
import TopBar from '../Navs/TopBar'
import Layout from '../Layout'
import Footer from '../Footer'
import Breadcrumb from '../_UI/Breadcrumb'
import PageTitle from '../_UI/PageTitle'
import styles from './TemplateArticle.module.css'
import { Backgrounds } from '../../assets'
import Image from 'next/image'
import React from 'react'
import Head from 'next/head'

const TemplateArticle = (props) => {
  const meta = {
    title: props?.pageMeta?.title ? props?.pageMeta?.title : 'منصة محمد السادس للحديث الشريف',
    description: props?.pageMeta?.description ? props?.pageMeta?.description : 'منصة محمد السادس للحديث الشريف',
    keywords:  props?.pageMeta?.keywords ?  props?.pageMeta?.keywords : '٫ اوقات الصلاة٫ وزارة الأوقاف والشؤون الإسلامية٫ اسلام٫ المغرب',
    type:'',
    ...props?.pageMeta,
  }
  console.log('pageMeta', props)
  return (
    <>
       
    
    <Layout className={`${styles.TemplateArticle}TemplateArticle`}>
    <Head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-NGQL2RC');`,
          }}
        ></script>
        <meta charSet='utf-8' />
        <meta name='viewport' content='width=device-width' />
        {/* <meta name='viewport' content='width=device-width, initial-scale=1' /> */}
        <meta name='theme-color' content='#129D59' />
        <meta name='description' content={meta?.description} />
        <meta
          name='keywords'
          content={meta?.keywords}
        />
        <link
          rel='apple-touch-icon'
          sizes='180x180'
          href='/apple-touch-icon.png'
        />
        <link
          rel='icon'
          type='image/png'
          sizes='32x32'
          href='/favicon-32x32.png'
        />
        <link
          rel='icon'
          type='image/png'
          sizes='16x16'
          href='/favicon-16x16.png'
        />
        <link rel='manifest' href='/site.webmanifest' />
        <meta name='msapplication-TileColor' content='#da532c' />
        <meta name='theme-color' content='#ffffff' />
        <link rel='preconnect' href='https://backend.hadithm6.com' />
        <link rel='preconnect' href='https://apisearch.hadithm6.com' />
        <link rel='preconnect' href='https://fonts.googleapis.com' />
        <link rel='preconnect' href='https://fonts.gstatic.com' crossOrigin />
        <link
          href='https://fonts.googleapis.com/css2?family=Almarai:wght@300&display=swap'
          rel='stylesheet'
        />
        <title>{meta?.title}</title>
      </Head>
      <TopBar {...props} />
      <NavBar />
      <div className={styles.bodyTemplate}>
        <div
          className={`${styles.templateHeader} template-header position-relative pb-2`}
        >
          <div
            className={` ${styles.bgDashed} p-1 flex-row-reverse position-absolute flex-row`}
            style={{ left: 10, marginTop: 10 }}
          >
            <Image
              alt={''}
              src={Backgrounds.bg_dashed}
              width={100}
              height={100}
              className={` bg_dashed h-100 position-absolute w-100`}
            />
          </div>
          <Breadcrumb data={props?.ListBreadcrumb} />
          {props.title === 't' ? null : (
            <PageTitle
              className={`${styles.pb0} pb-0 titre`}
              title={props?.titlePage}
              dateArticle={props?.dateArticlePage}
              created={props?.createdArticle}
            />
          )}
        </div>
        {props.children}
      </div>
      <Footer />
    </Layout>
    </>
  )
}

export default TemplateArticle
