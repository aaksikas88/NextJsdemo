import React from 'react'
import styles from './downloadAPK.module.css'
import { Icons } from '../../assets'
import Image from 'next/image'
import Link from 'next/link'

const DownloadApk = () => {
  return (
    <div className={`${styles.mobile} container`}>
      <Image src={Icons.icon_mobil} alt='' className={styles.iconMobile} />
      <div className={`container ${styles.downloadApk}`}>
        <div className={`${styles.download} p-4`}>
          <h4 className={`${styles.titleSec} `}>
            {'تحميل التطبيق الخاص بمنصة محمد السادس للحديث الشريف'}
          </h4>
          <div className={`${styles.iconGroup}`}>
            <Link href='https://play.google.com/store/apps/details?id=com.hadithApp'>
              <a target='_blank' rel='noreferrer'>
                <Image
                  src={Icons.icon_googlPlay}
                  alt='Android تحميل التطبيق الخاص بمنصة محمد السادس للحديث الشريف'
                  className={styles.dwdApk}
                />
              </a>
            </Link>
            <Link href='https://apps.apple.com/ma/app/%D9%85%D9%86%D8%B5%D8%A9-%D9%85%D8%AD%D9%85%D8%AF-%D8%A7%D9%84%D8%B3%D8%A7%D8%AF%D8%B3-%D9%84%D9%84%D8%AD%D8%AF%D9%8A%D8%AB-%D8%A7%D9%84%D8%B4%D8%B1%D9%8A%D9%81/id1625576030'>
              <a target='_blank' rel='noreferrer'>
                <Image src={Icons.icon_appStor} alt='تحميل التطبيق الخاص بمنصة محمد السادس للحديث الشريف Appel' className={styles.dwdApk} />
              </a>
            </Link>

          </div>
        </div>
      </div>
    </div>
  )
}

export default DownloadApk
