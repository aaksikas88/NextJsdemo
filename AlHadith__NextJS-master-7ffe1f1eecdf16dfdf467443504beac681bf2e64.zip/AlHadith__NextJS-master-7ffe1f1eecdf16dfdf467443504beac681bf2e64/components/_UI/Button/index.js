import React from "react";
import styles from'./Button.module.css';

const Button = () => {
    return (
        <div className={styles.m6Btn}>
            <button >hello</button>
        </div>
    );
}


export default Button
