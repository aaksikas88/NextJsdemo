import styles from './ItemList.module.css'
import React, { useState, useContext } from 'react'
import {
  FacebookIcon,
  FacebookShareButton,
  FacebookShareCount,
  LinkedinIcon,
  LinkedinShareButton,
  TwitterIcon,
  TwitterShareButton,
  WhatsappIcon,
  WhatsappShareButton,
} from 'react-share'
import Cards from '../_UI/Cards'
import Link from 'next/link'
import { AppContext } from '../../Context/AppContextApi'

const ItemList = (props) => {

  const {hadith,setHadith} = useContext(AppContext)

  const params =
    props.content +
    `\n# الحكم : ${props.degree} \n # الراوي : ${props.narrator} \n# المصدر : ${
      props.source
    } \n# مصدر الحكم : ${
      props.sourceGlobal ? props.sourceGlobal : ''
    } \n# الموضوع : ${props.category}  \n 
  منصة محمد السادس للحديث الشريف `
  const [show, setShow] = useState(false)
  const [message, setMessage] = useState('')
  const [content, setContent] = useState(params)
  const handleClose = () => setShow(false)
  const handleShow = () => setShow(true)

  function handleWhatsappshare() {
    if (props.content.length > 5510) {
      handleShow()
      setMessage('hello')
      return true
    }
    return false
  }

  const className = props?.className ? props.className : ''

  const regex = /(<([^>]+)>)/gi

  const text =
    props?.content.length <= 5110
      ? props?.content
      : props?.content
          ?.substring(0, 5110)
          .replace('\n', '')
          .replace(regex, '')
          .replace(/(\r\n|\n|\r)/gm, ' ') + '...'
  const params2 = `${text}\n# الحكم : ${props.degree.label} \n # الراوي : ${
    props.narrator
  } \n# المصدر : ${props.source} \n# مصدر الحكم : ${
    props.sourceGlobal ? props.sourceGlobal : ''
  } \n# الموضوع : ${props.category}  \n 
  منصة محمد السادس للحديث الشريف `

  const toShow = params.substring(0, 251) + ' ...'
  // console.log("toShow",toShow)

  const handleSetHadith = (item) => {
    setHadith(item)
  }

  return (
    <Cards
      className={`${styles.ItemList} my-2 w-100 px-0 pb-0 ${className} ${
        styles.result
      } result ${
        props.degree?.code === '1'
          ? styles.bckg1
          : props.degree?.code === '2'
          ? styles.bckg2
          : props.degree?.code === '28'
          ? 'bckgCard'
          : ''
      }`}
    >
      <div className={styles.content}>
        {props.highlight ? (
          <p
            className='m-0 content-hadith'
            dangerouslySetInnerHTML={{ __html: props.text }}
          />
        ) : (
          <p className='m-0 content-hadith'>{props.text}</p>
        )}
        <div className={`${styles.metaData} meta-data mt-3`}>
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex text-warning m-0 mb-2'>
              <span
                className={`fw-bold ${styles.output}`}
                style={{ color: '#b17d00' }}
              >
                الحكم
              </span>
              :{' '}
              <span className={`${styles.resultat} fw-bold`}>
                {props.degree?.label}
              </span>
            </p>
          </div>
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex text-success m-0 mb-2'>
              <span className={`text-success ${styles.output}`}>الراوي</span>:{' '}
              <span className={styles.resultat}>{props.narrator}</span>
            </p>
          </div>
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex m-0 mb-2'>
              <span className={styles.output} style={{ color: '#b17d00' }}>
                المصدر
              </span>
              : <span className={styles.resultat}>{props.source}</span>
            </p>

            {/* <div className="devider" />
            <p className="d-flex text-success m-0">
              <span className="text-success output">باب</span>:{' '}
              <span className="resultat">{props.topic}</span>
            </p> */}
          </div>
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex text-success m-0 mb-2'>
              <span className={`text-success ${styles.output}`}>
                مصدر الحكم
              </span>
              :<span className={styles.resultat}>{props.sourceGlobal}</span>
            </p>
          </div>
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex m-0 mb-2'>
              <span className={styles.output} style={{ color: '#b17d00' }}>
                الموضوع
              </span>
              : <span className={styles.resultat}>{props.category}</span>
            </p>
          </div>

          {props.comments && (
            <div
              className={`d-flex align-items-center alignItem ${styles.alignItem}`}
            >
              <p className='d-flex text-success m-0 mb-2'>
                {' '}
                <span className={`text-success ${styles.output}`}>
                  {' '}
                  ملاحظات{' '}
                </span>
                : <span className={styles.resultat}>{props.comments}</span>
              </p>
            </div>
          )}
          {props.showLink ? 
          <div
            className={`d-flex align-items-center alignItem pe-auto ${styles.alignItem}`}
            role="button"
            onClick={() => handleSetHadith(props)}
          >
            <Link
              passHref={true}
              exact
              role='button'
              href={{
                pathname:`/search/hadith/${'رقم-الحديث'}=${props.numeroHadith}&${'الموضوع'}=${props.category?.split(' ').join('-')}&${'المصدر'}=${props.source?.split(' ').join('-')}&${'الراوي'}=${props.narrator?.split(' ').join('-')}`,
                search: '',
                hash: '',
                query: {
                category: hadith?.category,
                narrator: hadith?.narrator,
                source: hadith?.source,
                degree: hadith?.degree,
                sourceGlobal: hadith?.sourceGlobal,
                numeroHadith: hadith?.numeroHadith,
                }
              }}
              as={`/search/hadith/${'رقم-الحديث'}=${props.numeroHadith}&${'الموضوع'}=${props.category?.split(' ').join('-')}&${'المصدر'}=${props.source?.split(' ').join('-')}&${'الراوي'}=${props.narrator?.split(' ').join('-')}`}
              style={{ color: 'black' }}
            >
              <a className='text-decoration-none'>
                <p className='d-flex m-0 mb-2'>
                  {' '}
                  <span className={`text-success ${styles.output}`}>
                    {' '}
                    رقم الحديث{' '}
                  </span>
                  : <span className={styles.resultat}>{props.numeroHadith}</span>
                </p>
              </a>
            </Link>
          </div>
          : 
          <div
            className={`d-flex align-items-center alignItem ${styles.alignItem}`}
          >
            <p className='d-flex m-0 mb-2'>
              {' '}
              <span className={`text-success ${styles.output}`}>
                {' '}
                رقم الحديث{' '}
              </span>
              : <span className={styles.resultat}>{props.numeroHadith}</span>
            </p>
          </div>
          }
        </div>
      </div>
      <hr />
      <div
        className={`sm-icons d-flex align-items-center flex-row mb-2`}
        style={{ alignItems: 'center' }}
      >
        <FacebookShareButton
          openShareDialogOnClick={props.showDialog}
          beforeOnClick={props.onSubmit}
          url={'https://hadithm6.ma/'}
          quote={params}
          className='justify-content-center mx-2'
        >
          <FacebookIcon size={32} round />
        </FacebookShareButton>
        <FacebookShareCount url={'https://hadithm6.ma/'} />
        <TwitterShareButton
          url={'https://hadithm6.ma/'}
          title={toShow}
          className='mx-2'
        >
          <TwitterIcon size={32} round />
        </TwitterShareButton>
        <WhatsappShareButton
          openShareDialogOnClick={props.showDialog}
          beforeOnClick={props.onSubmitWTSP}
          url={'https://hadithm6.ma/'}
          title={params2}
          separator={'\n'}
          className='mx-2'
        >
          <WhatsappIcon size={32} round />
        </WhatsappShareButton>
      </div>
    </Cards>
  )
}

export default ItemList
