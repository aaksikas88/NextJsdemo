import React from "react";


const VideosList = [
  {
    colorss: "FEB400",
    label: "برامج على الشبكات الاجتماعية",
    parentLabel: "البرامج الإعلامية",
    title: "برامج على الشبكات الاجتماعية"
  },
  {
    colorss: "129D59",
    // source: "https://img.youtube.com/vi/AOJ8emKkX-k/0.jpg",
    label: "برامج تلفزية",
    parentLabel: "البرامج الإعلامية",
    title:  "برامج تلفزية"
  },
  {
    colorss: "FF7D54",
    // source: "https://img.youtube.com/vi/AOJ8emKkX-k/0.jpg",
    label: "برامج اذاعية",
    parentLabel: "البرامج الإعلامية",
    title:  "برامج اذاعية",
  },
  {
    colorss: "1CD87C",
    // source: "https://img.youtube.com/vi/AOJ8emKkX-k/0.jpg",
    label: "الكراسي العلمية",
    parentLabel: "البرامج الإعلامية",
    title:  "الكراسي العلمية",
  },
  {
    colorss: "FEC480",
    // source: "https://img.youtube.com/vi/AOJ8emKkX-k/0.jpg",
    label: "الدروس الحديثية",
    parentLabel: "البرامج الإعلامية",
    title:  "الدروس الحديثية",
  },
]

export default VideosList
