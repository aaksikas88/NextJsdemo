export const data = [
  {
    eventKey: 'التمهيدية',
    title: 'الدروس التمهيدية',
    tid: '210',
  },
  {
    eventKey: 'البيانية',
    title: 'الدروس البيانية',
    tid: '211',
  },
  {
    eventKey: 'التفاعلية',
    title: 'الدروس التفاعلية',
    tid: '212',
  },
]
