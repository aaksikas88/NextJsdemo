import React from "react";

export const data =  [
    {
        eventKey:"الصحيحة",
        title:"الأحاديث الصحيحة",
        CodeTopic:1,
        content: "صحيح"
    },
    {
        eventKey:"الضعيفة",
        title:"الأحاديث الضعيفة",
        CodeTopic:2,
        content: 'ضعيف'
    },
    {
        eventKey:"الموضوعة",
        title:"الأحاديث الموضوعة",
        CodeTopic:28,
        content: "موضوع"
    },
]
