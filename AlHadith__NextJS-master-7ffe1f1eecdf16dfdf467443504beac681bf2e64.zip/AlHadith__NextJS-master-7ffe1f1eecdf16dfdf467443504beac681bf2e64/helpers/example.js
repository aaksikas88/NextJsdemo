const Example = () => {
   // console.log("Example func help")
}



export { Example }
