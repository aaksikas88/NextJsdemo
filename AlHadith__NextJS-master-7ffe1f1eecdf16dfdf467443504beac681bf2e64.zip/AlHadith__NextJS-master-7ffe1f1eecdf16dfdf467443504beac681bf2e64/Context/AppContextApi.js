import React, {createContext, useState} from 'react'

export const AppContext = createContext(null)

export const AppProvider = ({children}) => {
    const [infosId, setInfosId] = useState('')
    const [hadith, setHadith] = useState({})
    
    return(
        <AppContext.Provider value={{infosId, setInfosId,hadith, setHadith}}>
            {children}
        </AppContext.Provider>
    )
}